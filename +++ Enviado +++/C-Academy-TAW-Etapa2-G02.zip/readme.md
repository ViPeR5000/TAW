Grupo 2


### Identificação dos Elementos:
- Carlos Pimentel	[carlos.pimentel@outlook.pt]
- Rui Melo		[viper5000pt@gmail.com]
- Luís Moreira		[luismoreir@outlook.pt | luismoreir@gmail.com]

### Auto Avaliação do Grupo: 18 valores

### Auto Avaliação Individual:
- Carlos Pimentel	17 Valores
- Rui Melo		1 Valores
- Luís Moreira	15 Valores

### Descrição de tarefas:
- Carlos Pimentel	Apoio Estratégico, Code follower e Testes de Funcionalidades 
- Rui Melo 		Desenvolvimento e Final reviewer
- Luís Moreira		Desenvolvimento e Colaboração

### Funcionalidades extra.
- Limitar a taxa de pedidos para prevenir ataques de força bruta e DoS [sugestão: express-rate-limit];
- Guardar a imagem de perfil de forma segura e eficiente [sugestão: Multer + CDNs].
- Ciação de bashscripts para optimizar / automatizar tarefas ou ajudar na manutenção e despiste de erros
- Criação de VM de apoio para suporte e testes
- Criação de repositório git online para organizar o projeto em fases (pastas distintas) e histórico de commits atómicos focados por funcionalidade


### Links
- Git https://github.com/ViPeR5000/TAW/
- VM https://drive.google.com/drive/folders/1pm7MPKF5v4BlgmahKV3nw3REUKUwtX5f
