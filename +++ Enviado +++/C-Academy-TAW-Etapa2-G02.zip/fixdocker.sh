docker-compose down -v

